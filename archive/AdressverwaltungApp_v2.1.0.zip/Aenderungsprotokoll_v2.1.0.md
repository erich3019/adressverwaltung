# Änderungsprotokoll — Adressverwaltung v2.1.0

**Datum:** September 2026
**Grundlage:** Clean-Code-Analyse v2.0.0 (14 Befunde)
**Ziel:** Alle Befunde aus der Clean-Code-Analyse umsetzen

---

## Backend — Umgesetzte Befunde (B-01 bis B-08)

---

### B-01 ✅ SRP: Seed-Logik in eigene Klasse ausgelagert

**Neu:** `backend/AdressverwaltungApi/DbSeeder.cs`
**Geändert:** `backend/AdressverwaltungApi/Program.cs`

| Vorher | Nachher |
|---|---|
| Seed-Code direkt in `Program.cs` (Magic Strings) | `DbSeeder.Seed(db, hasher, config)` — eigene statische Klasse |
| `"admin@example.com"` und `"Test-1234!"` direkt im Code | Konfigurationswerte aus `Seed:AdminEmail` / `Seed:AdminPassword` |

```csharp
// Vorher (Program.cs)
if (!db.Users.Any()) {
    var admin = new User { Email = "admin@example.com", ... };
    admin.PasswordHash = hasher.HashPassword(admin, "Test-1234!");
    db.Users.Add(admin);
    db.SaveChanges();
}

// Nachher (Program.cs)
DbSeeder.Seed(db, hasher, config);

// Neu (DbSeeder.cs)
public static void Seed(AdresseDbContext db, IPasswordHasher<User> hasher, IConfiguration config) {
    if (db.Users.Any()) return;
    var email    = config["Seed:AdminEmail"]    ?? "admin@example.com";
    var password = config["Seed:AdminPassword"] ?? "Test-1234!";
    ...
}
```

---

### B-02 ✅ SRP: DTOs in eigene Dateien ausgelagert

**Neu:** `backend/AdressverwaltungApi/Dtos/AuthDtos.cs`
**Neu:** `backend/AdressverwaltungApi/Dtos/SettingsDtos.cs`
**Geändert:** `AuthController.cs` — DTO-Definitionen entfernt, `using AdressverwaltungApi.Dtos` hinzugefügt
**Geändert:** `SettingsController.cs` — DTO-Definitionen entfernt, `using AdressverwaltungApi.Dtos` hinzugefügt

| Vorher | Nachher |
|---|---|
| `RegisterRequest`, `LoginRequest` am Anfang von `AuthController.cs` | `Dtos/AuthDtos.cs` |
| `SettingsUpdateRequest` am Anfang von `SettingsController.cs` | `Dtos/SettingsDtos.cs` |

---

### B-03 ✅ SRP: Notification-Logik aus Controller ausgelagert

**Neu:** `backend/AdressverwaltungApi/Services/INotificationService.cs`
**Neu:** `backend/AdressverwaltungApi/Services/EmailNotificationService.cs`
**Geändert:** `Program.cs` — `AddScoped<INotificationService, EmailNotificationService>()` registriert
**Geändert:** `AdressenController.cs` — `IEmailService` durch `INotificationService` ersetzt

```csharp
// Vorher: private Hilfsmethode im Controller
private async Task SendNewAdresseNotificationAsync(Adresse adresse) { ... }

// Nachher: eigener Service
public interface INotificationService {
    Task NotifyNewAdresseAsync(Adresse adresse);
}
// Im Controller:
await _notificationService.NotifyNewAdresseAsync(adresse);
```

---

### B-04 ✅ Fehlerbehandlung: `int.Parse` → `int.TryParse`

**Geändert:** `Services/EmailService.cs`, Zeile 26–27

```csharp
// Vorher (wirft FormatException bei ungültigem Wert)
var smtpPort = int.Parse(_config["SmtpSettings:Port"] ?? "587");

// Nachher (sicherer Fallback auf 587)
if (!int.TryParse(_config["SmtpSettings:Port"], out var smtpPort))
    smtpPort = 587;
```

---

### B-05 ✅ Konfiguration: Schlüsselnamen vereinheitlicht

**Geändert:** `Services/EmailService.cs`
**Geändert:** `appsettings.json`

| Datei | Vorher | Nachher |
|---|---|---|
| `EmailService.cs` | `SmtpSettings:SenderEmail` | `SmtpSettings:FromAddress` |
| `appsettings.json` | `"SenderEmail": "..."` | `"FromAddress": "..."` |

Hinweis: `docker-compose.yml` verwendete bereits `SmtpSettings__FromAddress` — nun konsistent.

---

### B-06 ✅ Fehlerbehandlung: Culture-sicherer E-Mail-Vergleich

**Geändert:** `Controllers/AuthController.cs`, Register- und Login-Methode

```csharp
// Vorher (locale-abhängig, türkisches İ/i-Problem möglich)
u.Email.ToLower() == req.Email.ToLower()

// Nachher (culture-invariant via ToUpperInvariant / ToUpper in EF Core)
var emailNormalized = req.Email.Trim().ToUpperInvariant();
u.Email.ToUpper() == emailNormalized
```

---

### B-07 ✅ Validierung: DataAnnotations direkt am Model

**Geändert:** `Models/Adresse.cs`

```csharp
// Vorher: keine Annotations am Modell
public string Vorname { get; set; } = string.Empty;

// Nachher: Constraints direkt deklariert
[Required]
[MaxLength(100)]
public string Vorname { get; set; } = string.Empty;
```

Alle 6 Felder (`Vorname`, `Name`, `Strasse`, `Strassennummer`, `Plz`, `Ort`) mit `[Required]` und `[MaxLength]` versehen.

---

### B-08 ✅ DRY: Generische Basisklasse für OData-Controller

**Neu:** `backend/AdressverwaltungApi/Controllers/ODataCrudController.cs`
**Vereinfacht:** `AdressenController.cs` — erbt von `ODataCrudController<Adresse>`
**Vereinfacht:** `CitiesController.cs` — erbt von `ODataCrudController<City>`

```csharp
// Vorher: ~100 Zeilen CitiesController mit identischer CRUD-Logik wie AdressenController

// Nachher: CitiesController (7 Zeilen)
public class CitiesController : ODataCrudController<City>
{
    protected override DbSet<City> Entities     => _context.Cities;
    protected override string EntityDisplayName => "Stadt";
    public CitiesController(AdresseDbContext context) : base(context) { }
}
```

---

## Frontend — Umgesetzte Befunde (F-01 bis F-06)

---

### F-01 ✅ DRY: `normalizeAuditFields` Hilfsfunktion extrahiert

**Geändert:** `frontend/lib/api.ts`

```typescript
// Vorher: 6 Zeilen in normalizeAdresse + 6 Zeilen in normalizeCity (dupliziert)

// Nachher: gemeinsame Hilfsfunktion
function normalizeAuditFields(raw: Record<string, unknown>) {
  return {
    createDate: String(raw['createDate'] ?? raw['CreateDate'] ?? ''),
    ...
  };
}
// In beiden Normalize-Funktionen: ...normalizeAuditFields(raw)
```

---

### F-02 ✅ UI-Konsistenz: Alle Inputs controlled

**Geändert:** `frontend/components/AdresseForm.tsx`

| Feld | Vorher | Nachher |
|---|---|---|
| `vorname` | `defaultValue` (uncontrolled) | `value + onChange` (controlled) |
| `name` | `defaultValue` (uncontrolled) | `value + onChange` (controlled) |
| `strasse` | `defaultValue` (uncontrolled) | `value + onChange` (controlled) |
| `strassennummer` | `defaultValue` (uncontrolled) | `value + onChange` (controlled) |
| `plz` | bereits controlled | unverändert |
| `ort` | bereits controlled | unverändert |

`handleSubmit` liest nun direkt aus State statt aus `form.elements.namedItem(...)`.

---

### F-03 ✅ Fehlerbehandlung: `confirm()`/`alert()` ersetzt

**Neu:** `frontend/components/ConfirmDialog.tsx`
**Geändert:** `frontend/app/page.tsx`

```tsx
// Vorher
if (!confirm('Adresse wirklich löschen?')) return;
alert('Fehler beim Löschen der Adresse.');

// Nachher: State-basierter Dialog + inline Fehlermeldung
const [zuLoeschendId, setZuLoeschendId] = useState<number | null>(null);
const [loeschFehler, setLoeschFehler]   = useState<string | null>(null);

<ConfirmDialog
  offen={zuLoeschendId !== null}
  meldung="Adresse wirklich löschen?"
  onBestaetigen={handleLoeschenBestaetigt}
  onAbbrechen={() => setZuLoeschendId(null)}
/>
```

---

### F-04 ✅ TypeScript: NextAuth Session-Augmentation

**Neu:** `frontend/types/next-auth.d.ts`
**Geändert:** `frontend/lib/auth.ts`

```typescript
// Vorher (unsicherer Type-Cast)
(session.user as { id?: string }).id = token.id as string;

// Nachher (typsicher via Module Augmentation)
session.user.id = token.id;  // ← types/next-auth.d.ts erweitert Session-Typ
```

---

### F-05 ✅ Namensgebung: Tippfehler `suchelaeuft` → `sucheLaeuft`

**Geändert:** `frontend/components/AdresseForm.tsx`

```typescript
// Vorher
const [suchelaeuft, setSuchelaeuft] = useState(false);

// Nachher (korrekte camelCase-Konvention)
const [sucheLaeuft, setSucheLaeuft] = useState(false);
```

---

### F-06 ✅ Performance: `ladeDaten` mit `useCallback`

**Geändert:** `frontend/app/page.tsx`

```typescript
// Vorher: neue Referenz bei jedem Render
async function ladeDaten() { ... }

// Nachher: stabile Referenz
const ladeDaten = useCallback(async () => { ... }, []);
useEffect(() => { ladeDaten(); }, [ladeDaten]);
```

---

## Neue Dateien

| Datei | Inhalt |
|---|---|
| `backend/.../DbSeeder.cs` | Admin-Seed-Logik (SRP) |
| `backend/.../Dtos/AuthDtos.cs` | `RegisterRequest`, `LoginRequest` |
| `backend/.../Dtos/SettingsDtos.cs` | `SettingsUpdateRequest` |
| `backend/.../Services/INotificationService.cs` | Interface für Benachrichtigungen |
| `backend/.../Services/EmailNotificationService.cs` | E-Mail-Implementierung |
| `backend/.../Controllers/ODataCrudController.cs` | Generische CRUD-Basisklasse |
| `frontend/components/ConfirmDialog.tsx` | Eigener Bestätigungsdialog |
| `frontend/types/next-auth.d.ts` | NextAuth Session-Augmentation |

---

## Geänderte Dateien

| Datei | Befunde |
|---|---|
| `backend/.../Program.cs` | B-01, B-03 |
| `backend/.../Controllers/AuthController.cs` | B-02, B-06 |
| `backend/.../Controllers/SettingsController.cs` | B-02 |
| `backend/.../Controllers/AdressenController.cs` | B-03, B-08 |
| `backend/.../Controllers/CitiesController.cs` | B-08 |
| `backend/.../Services/EmailService.cs` | B-04, B-05 |
| `backend/.../appsettings.json` | B-05 |
| `backend/.../Models/Adresse.cs` | B-07 |
| `frontend/lib/api.ts` | F-01 |
| `frontend/components/AdresseForm.tsx` | F-02, F-05 |
| `frontend/app/page.tsx` | F-03, F-06 |
| `frontend/lib/auth.ts` | F-04 |
