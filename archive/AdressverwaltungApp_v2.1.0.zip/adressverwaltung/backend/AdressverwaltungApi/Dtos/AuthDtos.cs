using System.ComponentModel.DataAnnotations;

namespace AdressverwaltungApi.Dtos;

/// <summary>Request-Body für POST /auth/register</summary>
public record RegisterRequest(
    [Required][EmailAddress] string Email,
    [Required][MinLength(8)] string Password,
    [Required][MaxLength(100)] string DisplayName
);

/// <summary>Request-Body für POST /auth/login</summary>
public record LoginRequest(
    [Required][EmailAddress] string Email,
    [Required] string Password
);
