using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using AdressverwaltungApi.Data;
using AdressverwaltungApi.Dtos;
using AdressverwaltungApi.Models;

namespace AdressverwaltungApi.Controllers;

/// <summary>
/// Controller für Registrierung und Login.
/// Sicherheitshinweise:
/// - Passwörter werden mit ASP.NET Core PasswordHasher gehasht (PBKDF2 + Salt)
/// - Das PasswordHash-Feld wird NIEMALS in Responses zurückgegeben
/// - Fehlermeldungen sind bewusst generisch (kein Hinweis ob E-Mail oder Passwort falsch)
/// </summary>
[Route("auth")]
[ApiController]
public class AuthController : ControllerBase
{
    private readonly AdresseDbContext _context;
    private readonly IPasswordHasher<User> _hasher;

    public AuthController(AdresseDbContext context, IPasswordHasher<User> hasher)
    {
        _context = context;
        _hasher  = hasher;
    }

    // POST /auth/register
    [HttpPost("register")]
    public async Task<IActionResult> Register([FromBody] RegisterRequest req)
    {
        if (!ModelState.IsValid)
        {
            return BadRequest(ModelState);
        }

        // E-Mail case-insensitiv prüfen (B-06: ToUpper() statt ToLower() – culture-safe in EF Core)
        var emailNormalized = req.Email.Trim().ToUpperInvariant();
        var exists = await _context.Users.AnyAsync(u =>
            u.Email.ToUpper() == emailNormalized);

        if (exists)
        {
            // Gleiche Meldung wie bei Erfolg → kein User-Enumeration-Angriff möglich
            return Ok(new { message = "Falls diese E-Mail noch nicht registriert ist, wurde ein Konto erstellt." });
        }

        var user = new User
        {
            Email       = req.Email.Trim().ToLowerInvariant(),
            DisplayName = req.DisplayName.Trim(),
        };
        user.PasswordHash = _hasher.HashPassword(user, req.Password);

        _context.Users.Add(user);
        await _context.SaveChangesAsync();

        return Ok(new { message = "Registrierung erfolgreich." });
    }

    // POST /auth/login
    // Gibt { id, name, email } zurück – das Format, das NextAuth.js erwartet
    [HttpPost("login")]
    public async Task<IActionResult> Login([FromBody] LoginRequest req)
    {
        if (!ModelState.IsValid)
        {
            return BadRequest(ModelState);
        }

        // Benutzer anhand E-Mail suchen (B-06: culture-safe via ToUpper)
        var loginEmailNormalized = req.Email.Trim().ToUpperInvariant();
        var user = await _context.Users.FirstOrDefaultAsync(u =>
            u.Email.ToUpper() == loginEmailNormalized);

        // Passwort prüfen – bei ungültigem Benutzer trotzdem "prüfen"
        // (verhindert Timing-Angriffe durch gleiche Ausführungszeit)
        var dummyUser = new User();
        var hashToVerify = user?.PasswordHash ?? _hasher.HashPassword(dummyUser, "dummy");
        var verifyTarget = user ?? dummyUser;
        var result       = _hasher.VerifyHashedPassword(verifyTarget, hashToVerify, req.Password);

        if (user is null || result == PasswordVerificationResult.Failed)
        {
            // Bewusst generische Fehlermeldung
            return Unauthorized(new { message = "Ungültige Anmeldedaten." });
        }

        // Nur sichere Felder zurückgeben – NIEMALS PasswordHash!
        return Ok(new
        {
            id    = user.Id.ToString(),
            name  = user.DisplayName,
            email = user.Email,
        });
    }
}
