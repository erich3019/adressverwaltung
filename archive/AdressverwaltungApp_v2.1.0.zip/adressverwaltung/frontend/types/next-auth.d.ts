// F-04: NextAuth Session-Typen erweitern (Module Augmentation).
// Ermöglicht typsicheren Zugriff auf session.user.id, ohne Type-Cast.
// Vorher: (session.user as { id?: string }).id  ← unsicherer Cast
// Jetzt:  session.user.id                        ← typsicher

import 'next-auth';

declare module 'next-auth' {
  interface Session {
    user: {
      id: string;
      name?: string | null;
      email?: string | null;
      image?: string | null;
    };
  }
}

declare module 'next-auth/jwt' {
  interface JWT {
    id?: string;
  }
}
