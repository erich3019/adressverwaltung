using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Routing.Controllers;
using Microsoft.AspNetCore.OData.Query;
using Microsoft.AspNetCore.OData.Formatter;
using Microsoft.AspNetCore.OData.Deltas;
using Microsoft.EntityFrameworkCore;
using AdressverwaltungApi.Data;
using AdressverwaltungApi.Models;
using AdressverwaltungApi.Services;

namespace AdressverwaltungApi.Controllers;

public class AdressenController : ODataController
{
    private readonly AdresseDbContext _context;
    private readonly IEmailService _emailService;
    private readonly ILogger<AdressenController> _logger;

    public AdressenController(
        AdresseDbContext context,
        IEmailService emailService,
        ILogger<AdressenController> logger)
    {
        _context      = context;
        _emailService = emailService;
        _logger       = logger;
    }

    // GET /odata/Adressen
    [EnableQuery]
    public IActionResult Get()
    {
        return Ok(_context.Adressen.AsNoTracking());
    }

    // GET /odata/Adressen(5)
    [EnableQuery]
    public async Task<IActionResult> Get([FromRoute] int key)
    {
        var adresse = await _context.Adressen.FindAsync(key);

        if (adresse is null)
        {
            return NotFound($"Adresse mit Id {key} wurde nicht gefunden.");
        }

        return Ok(adresse);
    }

    // POST /odata/Adressen
    public async Task<IActionResult> Post([FromBody] Adresse adresse)
    {
        if (!ModelState.IsValid)
        {
            return BadRequest(ModelState);
        }

        _context.Adressen.Add(adresse);
        await _context.SaveChangesAsync();

        // E-Mail-Benachrichtigung senden (Fehler werden geloggt, blockieren nicht)
        await SendNewAdresseNotificationAsync(adresse);

        return Created(adresse);
    }

    // PATCH /odata/Adressen(5)
    public async Task<IActionResult> Patch(
        [FromRoute] int key,
        [FromBody] Delta<Adresse> delta)
    {
        if (!ModelState.IsValid)
        {
            return BadRequest(ModelState);
        }

        var adresse = await _context.Adressen.FindAsync(key);

        if (adresse is null)
        {
            return NotFound($"Adresse mit Id {key} wurde nicht gefunden.");
        }

        delta.Patch(adresse);

        if (!TryValidateModel(adresse))
        {
            return BadRequest(ModelState);
        }

        await _context.SaveChangesAsync();

        return Updated(adresse);
    }

    // DELETE /odata/Adressen(5)
    public async Task<IActionResult> Delete([FromRoute] int key)
    {
        var adresse = await _context.Adressen.FindAsync(key);

        if (adresse is null)
        {
            return NotFound($"Adresse mit Id {key} wurde nicht gefunden.");
        }

        _context.Adressen.Remove(adresse);
        await _context.SaveChangesAsync();

        return NoContent();
    }

    // ============================================================
    // Private Hilfsmethode: Benachrichtigung bei neuer Adresse
    // ============================================================

    private async Task SendNewAdresseNotificationAsync(Adresse adresse)
    {
        try
        {
            var settings = await _context.Settings.FirstOrDefaultAsync();

            if (settings is null || string.IsNullOrWhiteSpace(settings.NotificationEmail))
            {
                _logger.LogInformation(
                    "Keine Benachrichtigungs-E-Mail konfiguriert. Adresse {Id} gespeichert.", adresse.Id);
                return;
            }

            var betreff = $"Neue Adresse erfasst: {adresse.Vorname} {adresse.Name}";
            var inhalt  = $"""
                Neue Adresse wurde erfasst:

                Name:    {adresse.Vorname} {adresse.Name}
                Strasse: {adresse.Strasse} {adresse.Strassennummer}
                PLZ/Ort: {adresse.Plz} {adresse.Ort}
                """;

            await _emailService.SendAsync(settings.NotificationEmail, betreff, inhalt);
        }
        catch (Exception ex)
        {
            // Fehler beim E-Mail-Versand blockiert NICHT die API-Antwort
            _logger.LogError(ex, "Fehler beim E-Mail-Versand für Adresse {Id}.", adresse.Id);
        }
    }
}
