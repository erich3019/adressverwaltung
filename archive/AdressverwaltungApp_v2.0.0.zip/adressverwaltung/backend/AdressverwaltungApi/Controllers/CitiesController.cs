using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Routing.Controllers;
using Microsoft.AspNetCore.OData.Query;
using Microsoft.AspNetCore.OData.Deltas;
using Microsoft.EntityFrameworkCore;
using AdressverwaltungApi.Data;
using AdressverwaltungApi.Models;

namespace AdressverwaltungApi.Controllers;

/// <summary>
/// OData-Controller für die City-Entität.
/// Endpunkte: GET/POST/PATCH/DELETE /odata/Cities
/// </summary>
public class CitiesController : ODataController
{
    private readonly AdresseDbContext _context;

    public CitiesController(AdresseDbContext context)
    {
        _context = context;
    }

    // GET /odata/Cities
    [EnableQuery]
    public IActionResult Get()
    {
        return Ok(_context.Cities.AsNoTracking());
    }

    // GET /odata/Cities(5)
    [EnableQuery]
    public async Task<IActionResult> Get([FromRoute] int key)
    {
        var city = await _context.Cities.FindAsync(key);

        if (city is null)
        {
            return NotFound($"Stadt mit Id {key} wurde nicht gefunden.");
        }

        return Ok(city);
    }

    // POST /odata/Cities
    public async Task<IActionResult> Post([FromBody] City city)
    {
        if (!ModelState.IsValid)
        {
            return BadRequest(ModelState);
        }

        _context.Cities.Add(city);
        await _context.SaveChangesAsync();

        return Created(city);
    }

    // PATCH /odata/Cities(5)
    public async Task<IActionResult> Patch(
        [FromRoute] int key,
        [FromBody] Delta<City> delta)
    {
        if (!ModelState.IsValid)
        {
            return BadRequest(ModelState);
        }

        var city = await _context.Cities.FindAsync(key);

        if (city is null)
        {
            return NotFound($"Stadt mit Id {key} wurde nicht gefunden.");
        }

        delta.Patch(city);

        if (!TryValidateModel(city))
        {
            return BadRequest(ModelState);
        }

        await _context.SaveChangesAsync();

        return Updated(city);
    }

    // DELETE /odata/Cities(5)
    public async Task<IActionResult> Delete([FromRoute] int key)
    {
        var city = await _context.Cities.FindAsync(key);

        if (city is null)
        {
            return NotFound($"Stadt mit Id {key} wurde nicht gefunden.");
        }

        _context.Cities.Remove(city);
        await _context.SaveChangesAsync();

        return NoContent();
    }
}
