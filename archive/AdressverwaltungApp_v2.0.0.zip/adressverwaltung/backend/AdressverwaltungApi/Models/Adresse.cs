namespace AdressverwaltungApi.Models;

/// <summary>
/// Adress-Entität mit Audit-Feldern und Gültigkeitszeitraum.
/// Audit-Felder werden automatisch im DbContext befüllt.
/// </summary>
public class Adresse : AuditableEntity
{
    public int Id { get; set; }

    public string Vorname { get; set; } = string.Empty;

    public string Name { get; set; } = string.Empty;

    public string Strasse { get; set; } = string.Empty;

    public string Strassennummer { get; set; } = string.Empty;

    public string Plz { get; set; } = string.Empty;

    public string Ort { get; set; } = string.Empty;
}
