using Microsoft.AspNetCore.OData;
using Microsoft.AspNetCore.Identity;
using Microsoft.OData.ModelBuilder;
using Microsoft.EntityFrameworkCore;
using AdressverwaltungApi.Data;
using AdressverwaltungApi.Models;
using AdressverwaltungApi.Services;

var builder = WebApplication.CreateBuilder(args);

// === DATENBANK: Entity Framework Core mit PostgreSQL ===
builder.Services.AddDbContext<AdresseDbContext>(options =>
    options.UseNpgsql(
        builder.Configuration.GetConnectionString("DefaultConnection")
    )
);

// === HTTP-KONTEXT: Wird für Audit-Felder (CreatedBy/ChangedBy) benötigt ===
builder.Services.AddHttpContextAccessor();

// === PASSWORT-HASHING: ASP.NET Core PasswordHasher (PBKDF2 + Salt) ===
builder.Services.AddScoped<IPasswordHasher<User>, PasswordHasher<User>>();

// === E-MAIL-DIENST: SMTP-Implementierung (austauschbar via Interface) ===
builder.Services.AddScoped<IEmailService, EmailService>();

// === ODATA: EDM-Modell definieren ===
var modelBuilder = new ODataConventionModelBuilder();
modelBuilder.EnableLowerCamelCase(); // camelCase für alle Properties
modelBuilder.EntitySet<Adresse>("Adressen");
modelBuilder.EntitySet<City>("Cities");

// === CONTROLLERS + ODATA aktivieren ===
builder.Services.AddControllers()
    .AddJsonOptions(options =>
    {
        // camelCase für REST-Antworten (auth, settings)
        options.JsonSerializerOptions.PropertyNamingPolicy =
            System.Text.Json.JsonNamingPolicy.CamelCase;
    })
    .AddOData(options => options
        .Select()
        .Filter()
        .OrderBy()
        .SetMaxTop(100)
        .Count()
        .Expand()
        .AddRouteComponents("odata", modelBuilder.GetEdmModel())
    );

// === CORS: Nur Frontend-Ursprung erlauben ===
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowFrontend", policy =>
    {
        policy.WithOrigins(
                "http://localhost:3000",
                "http://frontend:3000"
              )
              .AllowAnyHeader()
              .AllowAnyMethod();
    });
});

// Swagger nur in Development (nicht in Production!)
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// === DATENBANK MIGRATION BEIM START ===
using (var scope = app.Services.CreateScope())
{
    var db      = scope.ServiceProvider.GetRequiredService<AdresseDbContext>();
    var hasher  = scope.ServiceProvider.GetRequiredService<IPasswordHasher<User>>();

    db.Database.Migrate();

    // ── SEED: Admin-Benutzer anlegen (nur wenn noch kein Benutzer existiert) ──
    if (!db.Users.Any())
    {
        var admin = new User
        {
            Email       = "admin@example.com",
            DisplayName = "Admin",
        };
        admin.PasswordHash = hasher.HashPassword(admin, "Test-1234!");

        db.Users.Add(admin);
        db.SaveChanges();
    }
}

// === MIDDLEWARE PIPELINE ===
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseCors("AllowFrontend");
app.UseRouting();
app.UseAuthorization();
app.MapControllers();

app.Run();
