import type { NextAuthOptions } from 'next-auth';
import CredentialsProvider from 'next-auth/providers/credentials';
import GoogleProvider from 'next-auth/providers/google';

// Für server-seitige Aufrufe (Docker: interner Service-Name)
const INTERNAL_API = process.env.INTERNAL_API_URL
  ?? process.env.NEXT_PUBLIC_API_URL
  ?? 'http://localhost:5000';

// Google OAuth nur aktivieren, wenn echte Credentials gesetzt sind
const googleClientId     = process.env.GOOGLE_CLIENT_ID     ?? '';
const googleClientSecret = process.env.GOOGLE_CLIENT_SECRET ?? '';
const googleEnabled      = googleClientId.length > 0 && googleClientSecret.length > 0;

export const authOptions: NextAuthOptions = {
  providers: [
    // ----------------------------------------------------------------
    // Credentials Provider: E-Mail + Passwort via Backend /auth/login
    // ----------------------------------------------------------------
    CredentialsProvider({
      name: 'E-Mail & Passwort',
      credentials: {
        email:    { label: 'E-Mail',   type: 'email',    placeholder: 'you@example.com' },
        password: { label: 'Passwort', type: 'password' },
      },
      async authorize(credentials) {
        if (!credentials?.email || !credentials?.password) return null;

        try {
          const response = await fetch(`${INTERNAL_API}/auth/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              email:    credentials.email,
              password: credentials.password,
            }),
          });

          if (!response.ok) return null;

          // Backend gibt { id, name, email } zurück (camelCase via JsonNamingPolicy)
          const user = await response.json() as {
            id:    string;
            name:  string;
            email: string;
          };

          return {
            id:    String(user.id),
            email: user.email,
            name:  user.name,
          };
        } catch {
          // Netzwerk- oder Parse-Fehler → Login verweigern
          return null;
        }
      },
    }),

    // ----------------------------------------------------------------
    // Google Provider (OAuth 2.0) – nur wenn Credentials konfiguriert
    // ----------------------------------------------------------------
    ...(googleEnabled
      ? [GoogleProvider({ clientId: googleClientId, clientSecret: googleClientSecret })]
      : []),
  ],

  // Eigene Login-Seite statt NextAuth-Default
  pages: {
    signIn: '/login',
  },

  // JWT-Session (kein Datenbank-Adapter nötig)
  session: {
    strategy: 'jwt',
    maxAge:   8 * 60 * 60, // 8 Stunden
  },

  callbacks: {
    // ID aus User-Objekt in den Token übernehmen
    async jwt({ token, user }) {
      if (user) {
        token.id = user.id;
      }
      return token;
    },
    // Token-Daten in Session-Objekt weitergeben
    async session({ session, token }) {
      if (token?.id && session.user) {
        (session.user as { id?: string }).id = token.id as string;
      }
      return session;
    },
  },

  secret: process.env.NEXTAUTH_SECRET,
};
